# Seatbelt

## Purpose

Windows security enumeration tool from GhostPack.

## Repository

https://github.com/GhostPack/Seatbelt

## Use in Methodology

1. Run only in an authorized environment.
2. Treat output as enumeration, not proof.
3. Manually validate security-relevant findings.
4. Record tool version and target context when documenting results.

## Limitations

- Tool coverage can become outdated.
- Security products can affect results.
- Findings can require configuration-specific validation.
- Version matching does not automatically prove exploitability.

## References

See the upstream project for current documentation and maintenance status.
